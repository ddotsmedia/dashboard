# ACCOUNTS DASHBOARD — CLAUDE.md
## Project Context & Safety Protocols

---

## PROJECT IDENTITY

**Project**: Accounts Dashboard (Enterprise Financial SaaS UI)  
**Repository**: `ddotsmedia/accounts-dashboard`  
**Type**: Frontend-only dashboard (no backend accounting engine)  
**Owner**: Ddotsmedia Technologies  
**VPS**: 194.164.151.202  
**Port**: 3115  
**PM2 ID**: (to assign)  

---

## CRITICAL RULES — NEVER VIOLATE

### ✅ ALWAYS DO

1. **Start every Claude Code session with this preamble:**
   ```
   Session rules: no pnpm db:seed, additive migrations only 
   (N/A for dashboard), never touch other VPS projects, 
   build+commit+push+deploy after each task, mobile-first, 
   TypeScript strict, Haiku default AI, keep prompts under 50 lines, 
   one feature per prompt.
   ```

2. **Read CLAUDE.md + TASKS.md before EVERY session** — not optional.

3. **Work incrementally** — follow Phase checklist, ONE phase per session max.

4. **Commit after every feature** — do not accumulate changes.

5. **Test before committing**:
   ```bash
   npm run lint        # ESLint
   npm run type-check  # TypeScript
   npm run test        # Jest (if applicable)
   npm run build       # Production build
   ```

6. **Use the data service abstraction** — never hard-code financial values in components.

7. **Maintain strict TypeScript** — zero `any`, zero `@ts-ignore` (document if unavoidable).

8. **Mobile-first design** — all components responsive from 320px up.

9. **Preserve existing working code** — do not delete or refactor working features.

10. **Use mock data service** — all UI pulls from centralized mock service, enabling API swap later.

---

### ❌ NEVER DO

1. **NEVER modify other Ddotsmedia VPS projects** — this project is standalone.
   - Do not touch: ayurconnect, ddots-erp, wa-crm, healthportal, ddotshop, ddotsjobs

2. **NEVER hard-code financial values in UI components.**
   ```javascript
   ❌ BAD: const revenue = 2845620; // directly in component
   ✅ GOOD: const { data: summary } = useFinancialData(filters);
   ```

3. **NEVER use `rm -rf` on project directories** — could delete work.

4. **NEVER skip testing** — always run full test suite before push.

5. **NEVER add dependencies without approval** — check if alternative exists in stack.

6. **NEVER create new database tables** — dashboard is frontend-only.

7. **NEVER store secrets in code** — use .env.local (git-ignored).

8. **NEVER commit .env files** — they are git-ignored.

9. **NEVER leave TypeScript errors in builds** — fix before committing.

10. **NEVER push to production without reviewing changes** — always review PR-style.

---

## TECHNOLOGY STACK (FIXED)

| Category | Technology |
|----------|------------|
| Framework | Next.js 16 (App Router) |
| Runtime | Node.js 18+ |
| Language | TypeScript 5.x (strict mode) |
| React Version | React 19 |
| Styling | Tailwind CSS 4.0 |
| UI Components | shadcn/ui (customized) |
| Tables | TanStack Table v8 |
| Data Fetching | TanStack Query v5 |
| State Management | Zustand |
| Charts | Apache ECharts 5.x |
| Forms | React Hook Form 7.x |
| Validation | Zod |
| Icons | Lucide React |
| Dates | date-fns |
| Drag & Drop | dnd-kit |
| Testing | Jest + React Testing Library + Playwright |
| Linting | ESLint + Prettier |
| Build | Next.js built-in |
| Deployment | PM2 + Nginx + Docker Compose (dev) |

**DO NOT swap these technologies** without explicit approval.

---

## PROJECT STRUCTURE (CANONICAL)

```
/opt/accounts-dashboard/
├── app/                      # Next.js App Router
│   ├── layout.tsx
│   ├── page.tsx
│   ├── dashboard/
│   ├── analytics/
│   ├── transactions/
│   ├── receivables/
│   ├── payables/
│   ├── cash-flow/
│   ├── budget/
│   ├── profitability/
│   ├── reports/
│   ├── ai-insights/
│   └── settings/
├── components/               # Reusable components
│   ├── dashboard/           # Dashboard-specific widgets
│   │   ├── kpi/
│   │   ├── charts/
│   │   ├── cash-flow/
│   │   ├── receivables/
│   │   ├── payables/
│   │   ├── profitability/
│   │   ├── budget/
│   │   ├── transactions/
│   │   ├── alerts/
│   │   └── ai-insights/
│   ├── navigation/          # Main layout, sidebar, header
│   ├── filters/             # Date range, company, currency selectors
│   ├── tables/              # TanStack tables
│   ├── widgets/             # Generic reusable widgets
│   └── ui/                  # shadcn/ui customizations
├── lib/
│   ├── api/                 # Data service layer (mock + real API abstraction)
│   │   ├── dashboardService.ts
│   │   └── mockDataService.ts
│   ├── charts/              # ECharts configuration
│   │   ├── chartConfig.ts
│   │   └── formatters.ts
│   ├── formatting/          # Currency, number, date formatters
│   │   ├── currency.ts
│   │   ├── numbers.ts
│   │   └── dates.ts
│   ├── dashboard/           # Dashboard-specific logic
│   │   ├── calculations.ts
│   │   └── ratios.ts
│   ├── permissions/         # RBAC (mock roles)
│   │   └── rbac.ts
│   └── utils/               # Utility functions
├── data/
│   └── mock/                # Mock data
│       ├── dashboardData.ts
│       ├── transactions.ts
│       ├── receivables.ts
│       ├── payables.ts
│       ├── budgets.ts
│       └── alerts.ts
├── types/                   # TypeScript type definitions
│   ├── dashboard.ts
│   ├── financial.ts
│   ├── user.ts
│   └── api.ts
├── config/                  # Configuration
│   └── constants.ts
├── hooks/                   # Custom hooks
│   ├── useFinancialData.ts
│   ├── useCurrency.ts
│   ├── useDateRange.ts
│   └── useDashboardCustomization.ts
├── styles/                  # Global styles
│   ├── globals.css
│   └── variables.css
├── tests/                   # Test files
│   ├── unit/
│   ├── components/
│   └── e2e/
├── .env.local               # Local secrets (git-ignored)
├── .env.production          # Production secrets (git-ignored)
├── .eslintrc.json
├── .gitignore
├── tailwind.config.ts
├── tsconfig.json
├── next.config.js
├── jest.config.js
├── package.json
├── package-lock.json
├── README.md
├── CLAUDE.md               # This file
├── TASKS.md                # Task tracking
└── deploy.sh               # Deployment script
```

**This structure is FIXED.** Do not reorganize without consensus.

---

## DATA ARCHITECTURE (CANONICAL)

```
UI Components
    ↓ (useFinancialData hook)
    ↓
Zustand Global State (filters, theme, customization)
    ↓
TanStack Query (caching, invalidation)
    ↓
Data Service (IDashboardService interface)
    ↓
Implementation: MockDashboardService | APIDashboardService
    ↓
Data: Mock data store | Real API endpoint
```

**DO NOT bypass this abstraction.**

Example (GOOD):
```typescript
// Component
export const DashboardCard = () => {
  const { data } = useFinancialData(filters);
  return <div>{formatCurrency(data.totalRevenue)}</div>;
};

// Hook
export const useFinancialData = (filters) => {
  return useQuery({
    queryKey: ['dashboard', filters],
    queryFn: () => dashboardService.getDashboardSummary(filters)
  });
};

// Service
export const dashboardService = process.env.NEXT_PUBLIC_USE_MOCK_DATA
  ? new MockDashboardService()
  : new APIDashboardService();
```

Example (BAD):
```typescript
// ❌ Hard-coded in component
export const DashboardCard = () => {
  const revenue = 2845620;
  return <div>{revenue}</div>;
};
```

---

## MOCK DATA REQUIREMENTS

1. **Consistent relationships** — revenue, expenses, profit must logically relate.
2. **Historical data** — 12+ months for trend analysis.
3. **Multiple entities** — companies, branches, departments, customers.
4. **Realistic distributions** — not random; use industry-typical ratios.
5. **Immutable** — do not modify mock data in components; copy if needed.

Mock data is centralized at `data/mock/dashboardData.ts`.

---

## SESSION WORKFLOW

### Before Starting

```bash
cd /opt/accounts-dashboard
git status  # Check clean working directory
git log -1  # Review last commit
```

### During Session

1. **Read CLAUDE.md + TASKS.md** (this file + task list)
2. **Pick ONE phase** from TASKS.md
3. **Check phase prerequisites** — all prior phases complete?
4. **Implement** using 14-step roadmap (PHASES 0–13)
5. **Test** before commit:
   ```bash
   npm run lint
   npm run type-check
   npm run test  # if applicable
   npm run build
   ```
6. **Commit & push**:
   ```bash
   git add .
   git commit -m "Phase X: [description]"
   git push origin main
   ```
7. **Update TASKS.md** — mark phase complete

### After Session

```bash
# Deploy if ready
bash /opt/accounts-dashboard/deploy.sh

# Or if not ready, just ensure pushed
git log -1  # Confirm push
```

---

## COMMON PITFALLS & HOW TO AVOID

| Pitfall | Cause | Fix |
|---------|-------|-----|
| Losing previous work | Didn't commit before refactor | Always commit before big changes |
| Type errors at build | Used `any` or `@ts-ignore` | Strict TypeScript, zero compromises |
| Performance issues | Heavy client-side rendering | Lazy-load, Suspense, memoize |
| Broken layout | Didn't test mobile | Test at 320px, 768px, 1920px |
| Hard-coded values | Bypassed service layer | Use hooks + service abstraction |
| Merge conflicts | Parallel editing same file | Modular components, clear ownership |
| Missing translations | Didn't add i18n keys | Use `useTranslation` hook, centralizedkeys |

---

## CONTACT & ESCALATION

If you encounter:

- **TypeScript errors you can't resolve** → Document error + context, ask for guidance
- **Architectural questions** → Review CLAUDE.md + TASKS.md + EXECUTION.md
- **Blocked by design decision** → Refer to 14-step roadmap + UI spec
- **Need to modify project structure** → Document rationale, get approval before changes

---

## SUCCESS CRITERIA

✅ Each phase completes with:
- Passing TypeScript checks (`tsc --noEmit`)
- Passing linting (`npm run lint`)
- Passing tests (if applicable)
- Passing production build
- Clean git history
- Documented changes in TASKS.md

✅ Final dashboard is:
- Enterprise-grade UI
- Responsive (mobile/tablet/desktop)
- Accessible (WCAG 2.2)
- Performant (Lighthouse 90+)
- Internationalized (EN/AR)
- Dark-mode ready
- Production-deployable

---

## REVISION HISTORY

- **2024-08-19**: Created CLAUDE.md + EXECUTION.md + TASKS.md
